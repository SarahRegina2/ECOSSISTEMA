package com.ecossistema.fenomenos;

public class Tempestade extends Fenomeno {
    @Override
    public void ocorrer() {
        System.out.println("Uma tempestade feroz desencadeia chuva intensa e ventos fortes.");
    }
}
