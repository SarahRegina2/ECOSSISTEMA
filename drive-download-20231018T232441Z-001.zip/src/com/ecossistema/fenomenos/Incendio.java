package com.ecossistema.fenomenos;

public class Incendio extends Fenomeno {
    @Override
    public void ocorrer() {
        System.out.println("Um incêndio devastador se espalha pela floresta.");
    }
}
