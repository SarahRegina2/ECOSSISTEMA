package com.ecossistema.fenomenos;

public abstract class Fenomeno {
    public abstract void ocorrer();
}
