package com.ecossistema.elementos;

import java.util.ArrayList;
import java.util.List;
import com.ecossistema.animais.Animal;
import com.ecossistema.plantas.Planta;
import com.ecossistema.fenomenos.Fenomeno;

public class Ecossistema {
    private List<Animal> animais;
    private List<Planta> plantas;
    private List<Fenomeno> fenomenos;

    public Ecossistema() {
        animais = new ArrayList<>();
        plantas = new ArrayList<>();
        fenomenos = new ArrayList<>();
    }

    public void adicionarAnimal(Animal animal) {
        animais.add(animal);
    }

    public void adicionarPlanta(Planta planta) {
        plantas.add(planta);
    }

    public void adicionarFenomeno(Fenomeno fenomeno) {
        fenomenos.add(fenomeno);
    }

    public void simular() {
        System.out.println("Simulação do ecossistema:");

        // Implemente a lógica de simulação aqui

        // Exemplo: Iterar sobre os animais e simular comportamentos
        for (Animal animal : animais) {
            animal.mover();
            animal.comer();
            animal.reproduzir();
        }

        // Iterar sobre as plantas e simular crescimento
        for (Planta planta : plantas) {
            planta.crescer();
        }

        // Iterar sobre os fenômenos e simular ocorrência
        for (Fenomeno fenomeno : fenomenos) {
            fenomeno.ocorrer();
        }
    }
}
