package com.ecossistema.elementos;

public class Noite {
    public void cicloNoturno() {
        System.out.println("É noite. A lua ilumina suavemente o ecossistema.");
    }
}
