package com.ecossistema.elementos;

public class Dia {
    public void cicloDiurno() {
        System.out.println("É dia. O sol brilha intensamente.");
    }
}
