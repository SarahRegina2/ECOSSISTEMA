package com.ecossistema.elementos;

import com.ecossistema.fenomenos.Fenomeno;

public class Sol extends Fenomeno {
    @Override
    public void ocorrer() {
        System.out.println("O sol brilha no céu, aquecendo o ecossistema.");
    }
}
